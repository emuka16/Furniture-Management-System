<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$orders_query = "SELECT * FROM purchase;";
$select_purchases = mysqli_query($connection, $orders_query);
$purchases = mysqli_fetch_all($select_purchases,MYSQLI_ASSOC);

require 'views\purchase\purchases.php';
