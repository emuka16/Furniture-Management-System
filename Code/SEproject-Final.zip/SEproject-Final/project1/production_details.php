<?php
ob_start();
session_start();
include 'includes/db.php';

$query ="SELECT * FROM production_details";
$select_products = mysqli_query($connection, $query);
$product_details = mysqli_fetch_all($select_products,MYSQLI_ASSOC);


require 'views\production_details\product_details.php';



 ?>
