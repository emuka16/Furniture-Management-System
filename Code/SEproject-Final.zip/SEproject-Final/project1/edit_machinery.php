<?php
session_start();
include 'includes/db.php';
include 'functions.php';

$the_machinery_id = null;
if(isset($_GET['edit_machinery'])){
    $the_machinery_id = $_GET['edit_machinery'];

 $query ="SELECT * FROM machineries WHERE id = $the_machinery_id;";
 $select_machinery_query = mysqli_query($connection, $query);

 $machinery = mysqli_fetch_assoc($select_machinery_query);
 confirm($machinery);

}


if(isset($_POST['edit'])){

  $name = $_POST['name'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  // var_dump($_FILES);
  $image = (isset($_FILES['image']['name'])&& !empty($_FILES['image']['name']))? $_FILES['image']['name']: null;
  $image_temp = (isset($_FILES['image']['tmp_name'])&& !empty($_FILES['image']['tmp_name']))? $_FILES['image']['tmp_name']: null;

  if(!empty($image) && (!empty($image_temp))){
  move_uploaded_file($image_temp, "/images/$image");
   }
   $query = "UPDATE machineries SET ";
   $query .= "name = '{$name}', ";
   $query .= "price = '{$price}', ";
   $query .= "quanity = '{$quantity}' ";
   $query .=($image)? "  ,image = '{$image}' " : " ";
   $query .= "  WHERE id = {$the_machinery_id} ;";

   $update_machinery = mysqli_query($connection,$query);
   confirm($update_machinery);
   header("Location: machineries.php");

}
 require 'views\machineries\edit_machinery.php';

    ?>
