<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

if(isset($_GET['id']) && !empty($_GET['id'])){
  $id = $_GET['id'];

$order_query = "SELECT * FROM purchase WHERE id='{$id}';";
$select_purchase = mysqli_query($connection, $order_query);
$purchase = mysqli_fetch_assoc($select_purchase);
// die(var_dump($order));

$purchase_material_query = "SELECT * FROM purchase_materials WHERE purchase_id='{$id}';";
$select_purchase_material = mysqli_query($connection, $purchase_material_query);
$purchase_materials = mysqli_fetch_all($select_purchase_material,MYSQLI_ASSOC);

$purchase_machineries_query = "SELECT * FROM purchase_machineries WHERE purchase_id='{$id}';";
$select_purchase_machineries = mysqli_query($connection, $purchase_machineries_query);
$purchase_machineries = mysqli_fetch_all($select_purchase_machineries,MYSQLI_ASSOC);

require 'views\purchase\purchase.php';
}
if(isset($_GET['delete']) && !empty($_GET['delete'])){
    $id = $_GET['delete'];
    $query ="DELETE  FROM purchase WHERE id = '{$id}'";
    $delete_query = mysqli_query($connection,$query);
    confirm($delete_query);


    header("Location: purchases.php");
}
