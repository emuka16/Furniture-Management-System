<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

if(isset($_GET['id']) && !empty($_GET['id'])){
  $id = $_GET['id'];

$production_details_query = "SELECT * FROM production_details WHERE id='{$id}';";
$select_production_details = mysqli_query($connection, $production_details_query);
$production = mysqli_fetch_assoc($select_production_details);
// die(var_dump($order));

$product_details_query = "SELECT * FROM product_detail WHERE production_id='{$id}';";
$select_product_details = mysqli_query($connection, $product_details_query);
$product_details = mysqli_fetch_all($select_product_details,MYSQLI_ASSOC);
require 'views\production_details\product_detail.php';
}
if(isset($_GET['delete']) && !empty($_GET['delete'])){
  $id = $_GET['delete'];
$query ="DELETE FROM product_detail WHERE production_id='{$id}';";
$delete_query = mysqli_query($connection,$query);


$query ="DELETE FROM production_details WHERE id='{$id}';";
$delete_query = mysqli_query($connection,$query);


header("Location: production_details.php");
}
