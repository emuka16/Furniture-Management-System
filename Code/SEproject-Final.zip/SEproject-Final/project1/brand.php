
<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

		$query ="SELECT * FROM brands";
		$select_brand = mysqli_query($connection, $query);
    $brands = mysqli_fetch_all($select_brand,MYSQLI_ASSOC);
	    require 'views\brand.php';



    if(isset($_GET['delete']))   {

    $the_brand_id = $_GET['delete'];

    $query ="DELETE FROM brands WHERE id = {$the_brand_id}";
    $delete_query = mysqli_query($connection,$query);
    header("Location: brand.php");
    }



    if(isset($_POST['add']))   {
      $name = $_POST['name'];
      $status = $_POST['status'];
        $query ="INSERT INTO brands(name, status)
        VALUES('{$name}', '{$status}');";
        $query_result = mysqli_query($connection,$query);
        confirm($query_result);

        header("Location: brand.php");
    }


?>
