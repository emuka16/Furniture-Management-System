
<?php
ob_start();
session_start();
  $url = "income_statements.php";
include 'includes/sidebar.php';
include 'includes/db.php';
include 'functions.php';

$month = (int) date('m');
$year = (int)date('Y');
$getIncome = "SELECT * FROM income_statements where month='{$month}' AND year='{$year}'; ";
$select_income_statement = mysqli_query($connection, $getIncome);
$income_statement = mysqli_fetch_assoc($select_income_statement);

require 'views\income_statements\edit_income_statement.php';
if(isset($_POST[edit])){
  $rent = $_POST['rent'];
  $tax = $_POST['tax'];
  $query = "UPDATE income_statements SET rent = '{$rent}', `taxes` = '{$tax}'
  WHERE (month='{$month}' AND year='{$year}')";
  $result =  mysqli_query($connection, $query);
  confirm($result);
  header("Location: income_statements.php");

}
