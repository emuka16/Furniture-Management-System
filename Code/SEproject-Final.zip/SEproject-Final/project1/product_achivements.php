<?php
ob_start();
session_start();
$url = "product_achivements.php";
include 'includes/sidebar.php';
include 'includes/db.php';
include 'functions.php';

$month = (int) date('m');
$year = (int)date('Y');

if(isset($_GET['month'])&& $_GET['month'] < $month){
  $current_month = $_GET['month'];
  $query ="SELECT * FROM product_achivements WHERE month= '{$current_month}' and year ='{$year}'; ";
  $select_achivements = mysqli_query($connection, $query);
  $achivements = mysqli_fetch_all($select_achivements,MYSQLI_ASSOC);
  if(sizeof($achivements) == 0){
    $query = "SELECT * FROM products;";
    $select_products = mysqli_query($connection, $query);
    $products = mysqli_fetch_all($select_products,MYSQLI_ASSOC);

    foreach($products as &$product){
      $query ="INSERT INTO product_achivements(product_id, product_name, achived_status, month, year, achived_no)
               VALUES('".$product['id']."', '".$product['name']."','0', '{$current_month}', '{$year}', 0);";
      $query_result = mysqli_query($connection,$query);
      confirm($query_result);
    }


  }
  require 'views\product_achivements\product_achivements.php';

}elseif(isset($_GET['month']) && $_GET['month'] > $month){
  $message = "No product achievement registered this month!";
  require 'views\messagePage.php';  }
else {
  $query ="SELECT * FROM product_achivements WHERE month= '{$month}' and year ='{$year}' ";
  $select_achivements = mysqli_query($connection, $query);
  $achivements = mysqli_fetch_all($select_achivements,MYSQLI_ASSOC);

  $query = "SELECT * FROM products;";
  $select_products = mysqli_query($connection, $query);
  $products = mysqli_fetch_all($select_products,MYSQLI_ASSOC);
  if(sizeof($achivements) == 0){
    foreach($products as &$product){
      $query ="INSERT INTO product_achivements(product_id, product_name, achived_status, month, year, achived_no)
               VALUES('".$product['id']."', '".$product['name']."','0', '{$month}', '{$year}', 0);";
      $query_result = mysqli_query($connection,$query);
      confirm($query_result);
    }
    $query ="SELECT * FROM product_achivements WHERE month= '{$month}' and year ='{$year}' ";
    $select_achivements = mysqli_query($connection, $query);
    $achivements = mysqli_fetch_all($select_achivements,MYSQLI_ASSOC);
  }
  else{
    foreach($products as &$product){
      $id = $product['id'];
      $flag = false;
      foreach ($achivements as &$achivement) {
        if($id == $achivement['product_id'])
          $flag=true;
      }
      if(!$flag){
        $query ="INSERT INTO product_achivements(product_id, product_name, achived_status, month, year, achived_no)
                 VALUES('".$product['id']."', '".$product['name']."','0', '{$month}', '{$year}', 0);";
        $query_result = mysqli_query($connection,$query);
        confirm($query_result);
      }
    }
    $query ="SELECT * FROM product_achivements WHERE month= '{$month}' and year ='{$year}' ";
    $select_achivements = mysqli_query($connection, $query);
    $achivements = mysqli_fetch_all($select_achivements,MYSQLI_ASSOC);

  }
  require 'views\product_achivements\current_product_achivement.php';
}

if(isset($_POST['edit'])){
  $achivement_id = $_POST['id'];
  $achived = $_POST['achived'];
  $goal = $_POST['goal'];

  $query ="SELECT * FROM product_achivements WHERE id= '{$achivement_id}'; ";
  $select_achivements = mysqli_query($connection, $query);
  $achivement = mysqli_fetch_all($select_achivements,MYSQLI_ASSOC);
  if($achivement){
    $update_query = "UPDATE product_achivements SET achived_status = '{$achived}',
   achived_no = '{$goal}'
    WHERE (id = '{$achivement_id}');";
    $query_result = mysqli_query($connection,$update_query);
    confirm($query_result);
  }
  header("Location: product_achivements.php");


}

?>