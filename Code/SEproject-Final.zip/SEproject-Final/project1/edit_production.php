<?php

ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

if(isset($_GET['update']) && !empty($_GET['update'])){
  $id = $_GET['update'];

$production_details_query = "SELECT * FROM production_details WHERE id='{$id}';";
$select_production_details = mysqli_query($connection, $production_details_query);
$production = mysqli_fetch_assoc($select_production_details);
if($production){
$product_details_query = "select p.production_id ,
p.material_id,
p.material_name,
p.material_cost from product_detail p where p.production_id = '{$id}'
union
select
'{$id}',
m.id ,
m.name,
0
from materials m
where m.id not in (
  select p.material_id from product_detail p where p.production_id = '{$id}'
);";
$select_product_details = mysqli_query($connection, $product_details_query);
$product_details = mysqli_fetch_all($select_product_details,MYSQLI_ASSOC);

} if(isset($_POST['update'])){
  // update production
  // delete all product details
  // create new product details

  $delete_query = "DELETE FROM product_detail WHERE production_id='{$id}'";
  $query_result = mysqli_query($connection, $delete_query);
  confirm($query_result);

  $get_materials = "SELECT * FROM materials;";
  $select_materials =  mysqli_query($connection, $get_materials);
  $materials = mysqli_fetch_all($select_materials,MYSQLI_ASSOC);
  confirm($select_materials);


$total=0;
  foreach ($materials as $material) {
    var_dump(kot);
    $mat_id = 'material_'.$material['id'];
    $name = 'material_name'.$material['id'];
    $cost = 'material_cost'.$material['id'];
    $material_cost =  $_POST[$cost];
    if($material_cost == 0)
    break;
    $total +=  $material_cost;
    $material_id = $_POST[$mat_id];
    $material_name = $_POST[$name];

    $query = "INSERT INTO product_detail( production_id, material_id, material_name, material_cost)
    VALUES('{$id}' ,'{$material_id}','{$material_name}', '{$material_cost}');";
    $query_result = mysqli_query( $connection, $query);

    confirm($query_result);

  }
  $machinery_cost = $_POST['machinery_cost'];
  $workig_hr = $_POST['work_hr_cost'];
  $total += $machinery_cost+ $work_hr;


  $update_production_query = "UPDATE production_details SET machinery_cost = '{$machinery_cost}',
  work_hr_cost = '{$workig_hr}', total_cost= $total";
  $query_result = mysqli_query( $connection, $update_production_query);

  confirm($query_result);

  header("Location: production_detail.php?id=".$id);

}
require 'views\production_details\update_production.php';
}


 ?>
