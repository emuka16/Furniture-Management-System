<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';
include 'helper/customer_helper.php';



$orders_query = "SELECT * FROM company_orders ;";
$select_orders = mysqli_query($connection, $orders_query);
$orders = mysqli_fetch_all($select_orders,MYSQLI_ASSOC);

$query ="SELECT * FROM customers";
$select_customers = mysqli_query($connection, $query);
$customers = mysqli_fetch_all($select_customers,MYSQLI_ASSOC);
$customer_map = get_customer_map($customers);

foreach ($orders as &$order) {
  $id= $order['order_to'];
  $order['to'] = $customer_map[$id];
}

require 'views\orders\orders.php';
