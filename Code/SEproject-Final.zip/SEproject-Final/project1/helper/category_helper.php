<?php

function get_category_map($categories){
  $cat_map = [];
  foreach ($categories as $categorie) {
    $cat_map[$categorie['id']] =  $categorie['name'];
  }
  return $cat_map;
}

 ?>
