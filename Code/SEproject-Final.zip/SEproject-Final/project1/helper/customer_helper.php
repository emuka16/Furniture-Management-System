<<?php

function get_customer_map($customers){
  $customer_map = [];
  foreach ($customers as $customer) {
    $customer_map[$customer['id']] =  $customer['name'];
  }
  return $customer_map;
}

 ?>
