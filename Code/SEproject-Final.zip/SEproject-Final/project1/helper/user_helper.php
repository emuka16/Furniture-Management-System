<?php
include 'includes\db.php';

function validateUser($data){
if(isset($data['username']) && isset($data['email']) && isset($data['password'])
 && isset($data['rpt_password']) && isset($data['name']) && isset($data['user_job'])){
// validating if the name has spaces and is not valid
   $username_validation = str_replace(' ', '_', $data['username']);
   if($data['username'] != $username_validation){
     $message = "Your username is not valid";
   require 'views\messagePage.php';
   die();
   }
   // validate psw and rpt_psw
   if($data['rpt_password'] !== $data['password']){
     $message = "Password not the same";
   require 'views\messagePage.php';
   die();
     }

return true;}
else return false;
}

function validateUserEmail($email, $id = null){
  $query_email = "SELECT * FROM users WHERE email = '{$email}' ";
  if(isset($id) && !empty($id))
  $query_email .= " AND id != '{$id}';";
  $query_results = mysqli_query($connection, $query_email);
  if(mysqli_num_rows($query_results)>0){
    return false;
  }
  return true;

}

function validateUsername($username, $id = null){
$query_username = "SELECT * FROM users WHERE username = '{$username}' ;";
if(isset($id) && !empty($id))
$query_email .= " AND id != '{$id}';";
$query_results = mysqli_query($connection,$query_username);
if(mysqli_num_rows($query_results)>0){
  return false;
}
return true;
}