<?php

function get_brand_map($brands){
  $brand_map = [];
  foreach ($brands as $brand) {
    $brand_map[$brand['id']] =  $brand['name'];
  }
  return $brand_map;
}

 ?>
