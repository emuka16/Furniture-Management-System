<?php

function get_product_id($products, $id){
  $name = '';
  foreach ($products as &$product) {
   if($product['id'] == $id ){
     $name = $product['name'];
   }
  }
  return $name;
}
 ?>
