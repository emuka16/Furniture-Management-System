<?php

function get_departament_map($departaments){
  $dep_map = [];
  foreach ($departaments as $departament) {
    $dep_map[$departament['id']] =  $departament['name'];
  }
  return $dep_map;
}

 ?>
