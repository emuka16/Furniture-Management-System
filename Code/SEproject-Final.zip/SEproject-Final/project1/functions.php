<?php

function confirm($result){
if(!$result){
    global $connection;

      $message = "FAILDDD" .mysqli_error($connection);
    require 'views\messagePage.php';
    die();


  }
}
