
<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

		$query ="SELECT * FROM departaments";
		$select_departaments = mysqli_query($connection, $query);
    $departaments = mysqli_fetch_all($select_departaments,MYSQLI_ASSOC);
	    require 'views\departaments.php';



    if(isset($_GET['delete']))   {

    $the_departament_id = $_GET['delete'];

    $query ="DELETE FROM departaments WHERE id = {$the_departament_id}";
    $delete_query = mysqli_query($connection,$query);
    header("Location: departamets.php");
    }



    if(isset($_POST['add']))   {
      $name = $_POST['name'];
        $query ="INSERT INTO departaments(name)
        VALUES('{$name}');";
        $query_result = mysqli_query($connection,$query);
        confirm($query_result);

        header("Location: departamets.php");
    }


?>
