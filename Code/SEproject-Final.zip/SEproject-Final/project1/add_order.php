<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$query ="SELECT * FROM products";
$select_products = mysqli_query($connection, $query);
$products = mysqli_fetch_all($select_products,MYSQLI_ASSOC);

$query ="SELECT * FROM customers";
$select_customers = mysqli_query($connection, $query);
$customers = mysqli_fetch_all($select_customers,MYSQLI_ASSOC);


if(isset($_POST['add'])){
  $from = $_POST['order_from'];
  $to = $_POST['order_to'];

  $query ="SELECT * FROM customers WHERE id='{$to}'";
  $select_customer = mysqli_query($connection, $query);
  $customer = mysqli_fetch_assoc($select_customer);
  $address = $customer['address'];

  // kontrollon per pjesen e producteve(items)
  /**
we take the items from the html form with name as product_name_id
in the foreach we control if the product is selected and if we have a quantity for the product selected
we create an associative array with information that are like records in the db
  **/
  $flag = false;
  $order_products = [];
  $subtotal = 0;
foreach ($products as &$product) {
  $key = $product['name'];
  if(isset($_POST[$key]) && !empty($_POST[$key])){
    $flag = true;
    $order_product['product_name'] = $key;
    $order_product['id'] = $product['id'];
    $quantity = 'item_'.$product['id'];
    $order_product['quantity'] = $_POST[$quantity];
    $order_product['unit_price'] = $product['price'];
    $order_product['total'] = $_POST[$quantity] * $product['price'];
    $subtotal += $order_product['total'];
    $order_products[] =$order_product;
  }
}
/**
if there are no products, we are creating a void order
 that does not make sens that's why we thro a message to the user**/
if(!$flag){
  $message = "There are no products in order";
require 'views\messagePage.php';
}

$tax = (isset($_POST['tax'])&& !empty($_POST['tax']))? ($_POST['tax']) : 0;
$shipping = (isset($_POST['shipping'])&& !empty($_POST['shipping']))? ($_POST['shipping']) : 0;
$total = $subtotal + $tax + $shipping ;
$special_notes = (isset($_POST['notes'])&& !empty($_POST['notes']))? ($_POST['notes']) : " ";

// create the order and get the id of the specific record added
$query = "INSERT INTO company_orders(order_from, order_to, address)
VALUES( '{$from}', '{$to}', '{$address}');";

$query_result = mysqli_query( $connection, $query);
confirm($query_result);
$order_id =(int) mysqli_insert_id($connection);

// create the order_products for each product added in the order modul
foreach ($order_products as $order_product) {

  $query = "INSERT INTO order_products( product_id, product_name, quantity, unit_price, total, order_id, order_time)
  VALUES('". $order_product['id'] ."', '".$order_product['product_name']."', '".$order_product['quantity']."',
    '".$order_product['unit_price']."', '".$order_product['total']."', '{$order_id}', now());";
  $query_result = mysqli_query( $connection, $query);
  confirm($query_result);
}

// create the invoice of the order that will have financal information.
$query = "INSERT INTO invoice_orders(order_from, order_to, order_time, subtotal, tax, shipping, total, special_notes, order_id)
VALUES( '{$from}', '{$to}', now(), '{$subtotal}', '{$tax}', '{$shipping}', '{$total}', '{$special_notes}', '{$order_id}' );";

$query_result = mysqli_query( $connection, $query);
confirm($query_result);




// REDIRECT
header("Location: orders.php");



}
require 'views\orders\add_order.php';
