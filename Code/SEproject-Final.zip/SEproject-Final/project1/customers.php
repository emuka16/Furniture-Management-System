<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$query = "SELECT * FROM customers";
$select_customers = mysqli_query($connection, $query);
$customers = mysqli_fetch_all($select_customers, MYSQLI_ASSOC);
require 'views\customers.php';




if (isset($_GET['delete'])) {

  $the_customer_id = $_GET['delete'];

  $query = "DELETE FROM customers WHERE id = {$the_customer_id}";
  $delete_query = mysqli_query($connection, $query);
  header("Location: customers.php");
}



if (isset($_POST['add'])) {
  $name = $_POST['name'];
  $address = $_POST['address'];
  $phone_number = (isset($_POST['phone_number']) && !empty($_POST['phone_number'])) ? $_POST['phone_number'] : null;
  $query = "INSERT INTO customers(name, address, phone_number)
  VALUES('{$name}', '{$address}', '{$phone_number}');
  ";
  $query_result = mysqli_query($connection, $query);
  confirm($query_result);

  header("Location: customers.php");
}



if (isset($_POST['edit'])) {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $address = $_POST['address'];
  $phone_number = (isset($_POST['phone_number']) && !empty($_POST['phone_number'])) ? $_POST['phone_number'] : null;


  $query = "UPDATE customers SET
  name = '{$name}',
    address = '{$address}',
    phone_number = '{$phone_number}'
  WHERE id = '{$id}';
  ";
  $query_result = mysqli_query($connection, $query);
  confirm($query_result);

  header("Location: customers.php");
}

?>
