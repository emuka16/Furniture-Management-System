<?php session_start();
 include "db.php";

$username = $_POST['username'];
$password = $_POST['password'];

$username = mysqli_real_escape_string($connection , $username);
$password = mysqli_real_escape_string($connection , $password);
$password = base64_encode($password);

$query = "SELECT * FROM users WHERE username ='{$username}' ";
$select_user_query = mysqli_query($connection,$query);

if(!$select_user_query){
    die(mysqli_error($connection));
}

 $row = mysqli_fetch_array($select_user_query);
    $db_user_id = $row['id'];
    $db_username = $row ['username'];
    $db_user_role = $row ['type'];
    $db_user_password = $row ['password'];

if(($username == $db_username) && ($password == $db_user_password) ) {
    $_SESSION['username'] = $db_username;
    $_SESSION['id'] = $db_user_id;
    $_SESSION['type'] = $db_user_role;
    session_write_close();
    header("Location: ../index.php");
    exit();

} else {
  die("incorrect !!!");
}
