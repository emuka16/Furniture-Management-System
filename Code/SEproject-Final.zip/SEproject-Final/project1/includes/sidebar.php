<!-- it is shown in production and income_statements
it is a list that shows every month
 -->

<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Project</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/blog-home.css" rel="stylesheet">
</head>

<body>
  <br>
  <br>
<div class="col-md-2">

<!-- Blog Categories Well -->
<div class="well">
    <h4> Months </h4>
    <div class="row">
        <div class="col-lg-11">
            <ul class="list-unstyled">



      <li><a href='<?=$url;?>?month=1'>January</a> </li>
      <li><a href='<?=$url;?>?month=2'>February</a> </li>
      <li><a href='<?=$url;?>?month=3'>March</a> </li>
      <li><a href='<?=$url;?>?month=4'>April</a> </li>
      <li><a href='<?=$url;?>?month=5'>May</a> </li>
      <li><a href='<?=$url;?>?month=6'>June</a> </li>
      <li><a href='<?=$url;?>?month=7'>July</a> </li>
      <li><a href='<?=$url;?>?month=8'>August</a> </li>
      <li><a href='<?=$url;?>?month=9'>September</a> </li>
      <li><a href='<?=$url;?>?month=10'>October</a> </li>
      <li><a href='<?=$url;?>?month=11'>November</a> </li>
      <li><a href='<?=$url;?>?month=12'>December</a> </li>


            </ul>
        </div>
    </div>
    <!-- /.row -->
</div>

<!-- Side Widget Well -->
<?php include "widget.php"; ?>
</div>

</div>
</body>
