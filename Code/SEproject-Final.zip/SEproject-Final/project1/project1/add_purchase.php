<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$query ="SELECT * FROM materials";
$select_materials = mysqli_query($connection, $query);
$materials = mysqli_fetch_all($select_materials,MYSQLI_ASSOC);

$query ="SELECT * FROM machineries";
$select_machineires = mysqli_query($connection, $query);
$machineries = mysqli_fetch_all($select_machineires,MYSQLI_ASSOC);

if(isset($_POST['add'])){
  $from = $_POST['From'];
  $to = $_POST['To'];

  // kontrollon per pjesen e producteve(items)
  $flag = false;
  $purchase_materials = [];
  $subtotal = 0;
foreach ($materials as &$material) {
  $key = $material['name'];
  if(isset($_POST[$key]) && !empty($_POST[$key])){
    $flag = true;
    $purchase_material['material_name'] = $key;
    $purchase_material['id'] = $material['id'];
    $quantity = 'material_'.$material['id'];
    $purchase_material['quantity'] = $_POST[$quantity];
    $purchase_material['unit_price'] = $material['price'];
    $purchase_material['total'] = $_POST[$quantity] * $material['price'];
    $subtotal += $purchase_material['total'];
    $purchase_materials[] =$purchase_material;
  }
}
if(!$flag){
  $message = "There are no products in purchase";
require 'views\messagePage.php';
}

$flag1=false;
$purchase_machineries = [];
foreach ($machineries as &$machinery) {
  $key = $machinery['name'];
  if(isset($_POST[$key]) && !empty($_POST[$key])){
    $flag1 = true;
    $purchase_machinery['machinery_name'] = $key;
    $purchase_machinery['id'] = $machinery['id'];
    $quantity = 'machinery_'.$machinery['id'];
    $purchase_machinery['quantity'] = $_POST[$quantity];
    $purchase_machinery['unit_price'] = $machinery['price'];
    $purchase_machinery['total'] = $_POST[$quantity] * $machinery['price'];
    $subtotal += $purchase_machinery['total'];
    $purchase_machineries[] = $purchase_machinery;
  }
}
if(!$flag1){
  $message = "There are no products in purchase";
require 'views\messagePage.php';
}
// llogarit total
$tax = (isset($_POST['tax'])&& !empty($_POST['tax']))? ($_POST['tax']) : 0;
$shipping = (isset($_POST['shipping'])&& !empty($_POST['shipping']))? ($_POST['shipping']) : 0;
$total = $subtotal + $tax + $shipping ;
$special_notes = (isset($_POST['notes'])&& !empty($_POST['notes']))? ($_POST['notes']) : " ";

$query = "INSERT INTO purchase(koha, nga, per, subtotal, tax, shiping, total, special_notes)
VALUES(now(), '{$from}', '{$to}', '{$subtotal}', '{$tax}', '{$shipping}', '{$total}', '{$special_notes}');";

$query_result = mysqli_query( $connection, $query);
confirm($query_result);
$purchase_id =(int) mysqli_insert_id($connection);


foreach ($purchase_materials as $purchase_material) {
  $query = "INSERT INTO purchase_materials( material_id, material_name, quantity, unit_price, total, purchase_id)
  VALUES('". $purchase_material['id'] ."','".$purchase_material['material_name']."', '".$purchase_material['quantity']."',
    '".$purchase_material['unit_price']."','".$purchase_material['total']."', '{$purchase_id}');";
// die(var_dump($query));
  $query_result = mysqli_query( $connection, $query);

  confirm($query_result);
}

foreach ($purchase_machineries as $purchase_machinery) {

  $query = "INSERT INTO purchase_machineries( machinery_id, machinery_name, quantity, unit_price, total, purchase_id, status)
  VALUES('". $purchase_machinery['id'] ."','".$purchase_machinery['machinery_name']."', '".$purchase_machinery['quantity']."',
    '".$purchase_machinery['unit_price']."','".$purchase_machinery['total']."', '{$purchase_id}'), '1';";
// die(var_dump($query));
  $query_result = mysqli_query( $connection, $query);

  confirm($query_result);
}

header("Location: ../purchases.php");



}
require 'views\purchase\add_purchase.php';
