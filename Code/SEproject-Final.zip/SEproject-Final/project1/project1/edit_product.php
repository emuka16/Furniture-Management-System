<?php
session_start();
include 'includes/db.php';
include 'helper/user_helper.php';
include 'functions.php';

$the_product_id = null;
if(isset($_GET['edit_product'])){
    $the_product_id = $_GET['edit_product'];

 $query ="SELECT * FROM products WHERE id = $the_product_id;";
 $select_product_query = mysqli_query($connection, $query);

 $product = mysqli_fetch_assoc($select_product_query);

 $query ="SELECT * FROM brands";
 $select_brands = mysqli_query($connection, $query);
 $brands = mysqli_fetch_all($select_brands,MYSQLI_ASSOC);
}


if(isset($_POST['edit'])){

  $name = $_POST['name'];
  $brand_id = $_POST['brand_id'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $description = (isset($_POST['description'])&& !empty($_POST['description']))? $_POST['description']: null;
  $availability = $_POST['availability'];
  $parameters = (isset($_POST['parameters'])&& !empty($_POST['parameters']))? $_POST['parameters']: null;
  $image = (isset($_FILES['image']['name'])&& !empty($_FILES['image']['name']))? $_FILES['image']['name']: null;
  $image_tmmp = (isset($_FILES['image']['tmp_name'])&& !empty($_FILES['image']['tmp_name']))? $_FILES['image']['tmp_name']: null;

  if(!empty($image) && (!empty($image_tmmp))){
  move_uploaded_file($image_temp, "images/$image");
   }
   $query = "UPDATE products SET ";
   $query .= "name = '{$name}', ";
   $query .= "brand_id = '{$brand_id}', ";
   $query .= "price = '{$price}', ";
   $query .= "quantity = '{$quantity}', ";
   $query .= "description = '{$description}', ";
   $query .= "availability = '{$availability}', ";
   $query .= "parameters = '{$parameters}' ";
   $query .=($image)? "  ,image = '{$image}' " : " ";
   $query .= "  WHERE id = {$the_product_id} ;";

   $update_product = mysqli_query($connection,$query);
   confirm($update_product);
   header("Location: ../products.php");

}
 require 'views\products\edit_product.php';

    ?>
