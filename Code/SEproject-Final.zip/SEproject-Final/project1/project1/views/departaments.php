
<?php
$css = "\css\\table.css";
include 'includes/navigation.php';
 ?>
<body>

<h2>Departaments</h2>
<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($departaments  as $departament) { ?>
      <tr>
        <td><?=$departament['id']; ?></td>
          <td><?=$departament['name']; ?></td>
      <form method="GET" action="">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$departament['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	}
		?>


    <tr>
    <form method="POST" action="">
      <td>
          <strong> NEW DEPARTAMENT</strong>
      </td>
      <td>
        <input type="text" name="name" required>
      </td>
      <td>
        <button type="submit" name="add">ADD</button>
      </td>
    </form>
    </tr>
 </tbody>
</table>
</div>
</body>
