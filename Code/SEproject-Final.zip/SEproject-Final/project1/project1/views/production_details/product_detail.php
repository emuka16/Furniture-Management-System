
	<?php
	$css = "\css\ordePurchuase.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-12 brandSection">
                <div class="row">
                    <div class="col-md-12 col-sm-12 header">
                        <div class="col-md-3 col-sm-3 headerLeft">
                            <h1>Production Detail</h1>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 content">
                        <h1>Production Detail for <strong>  <?=$production['product_name']; ?></strong></h1>
                        <p><?=$production['production_time']; ?></p>
                    </div>
                        <div class="col-md-12 col-sm-12 tableSection">
                            <h1>Material Costs</h1>
                            <table class="table text-center">
                              <thead>
                                <tr class="tableHead">
                                  <th>Material ID </th>
                                  <th>Material Name</th>
                                  <th>Material Cost</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($product_details as $product_detail) { ?>
                                  <tr>
                                    <td><?=$product_detail['material_id']; ?></td>
                                    <td><?=$product_detail['material_name']; ?></td>
                                    <td><?=$product_detail['material_cost']; ?></td>
                                  </tr>
                                <?php } ?>
                              </tbody>
                          </table>
                        </div>
                        <div class="col-md-12 col-sm-12 lastSectionleft ">
                            <div class="row">
                                <div class="col-md-8 col-sm-6 Sectionleft">
                                    <span><i>Production Details</i> </span>
                                </div>
                                <div class="col-md-8 col-sm-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body lastPanel">
                                          Total Cost
                                      </div>
                                      <div class="panel-footer lastFooter">
                                          <div class="row">
                                              <div class="col-md-5 col-sm-6 col-xs-6 panelLastLeft">
                                                <p>Machinery Cost</p>
                                                <p>Working Hour Cost</p>
                                                <p>TOTAL</p>
                                              </div>
                                              <div class="col-md-7 col-sm-6 col-xs-6 panelLastRight">
                                                <p>$<?=$production['machinery_cost']; ?></p>
                                                <p>$<?=$production['work_hr_cost']; ?></p>
                                                <p><strong>$<?=$production['total_cost']; ?></strong></p>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                </div>
																<br>
																<br>

				                    <form method="GET" action="edit_production.php">
				                          <button type="submit" name="update" value="<?=$production['id']; ?>">UPDATE</button>
				                    </form>
														<br>
                            </div>

                        </div>
                    </div>
                        <br>

                    <form method="GET" action="">
                          <button type="submit" name="delete" value="<?=$production['id']; ?>">DELETE</button>
                    </form>
										<br>
                </div>
                </div>


        </div>


    </div>

</body>
</html>
