
<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
?>

<body>
  <h2>Product Details </h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>Product Name</th>
            <th>Cost</th>
            <th>Time Of Production </th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($product_details as &$product_detail) { ?>
      <tr>
        <td><a href="production_detail.php?id=<?=$product_detail['id']; ?>"><?= 'ProductDetail '.$product_detail['id']; ?></a></td>
          <td><?=$product_detail['product_name']; ?></td>
          <td><?=$product_detail['total_cost']; ?></td>
          <td><?=$product_detail['production_time']; ?></td>
	<?php	}
		?>
    <tr rawspan="2">
        <form method="GET" action="add_production_details.php">
            <td colspan="4">
              <button type="submit">ADD Production Informaion</button>
            </td>
        </form>
    </tr>
 </tbody>
</table>
</div>
</body>
