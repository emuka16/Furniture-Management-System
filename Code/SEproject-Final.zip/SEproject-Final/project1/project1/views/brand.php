
<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
<body>
  <h2>Brands registered in the system</h2>
<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>status</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($brands as $brand) { ?>
      <tr>
        <td><?=$brand['id']; ?></td>
          <td><?=$brand['name']; ?></td>
          <td><?=$brand['status']; ?></td>
      <form method="GET" action="brand.php">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$brand['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	}
		?>


    <tr>
    <form method="POST" action="">
      <td>
          <strong> NEW Brand</strong>
      </td>
      <td>
        <input type="text" name="name" required>
      </td>
      <td>
          <input type="number" name="status" required>
      </td>
      <td colspan="2">
        <button type="submit" name="add">ADD</button>
      </td>
    </form>
    </tr>
 </tbody>
</table>
</div>
</body>
