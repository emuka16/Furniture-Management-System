
<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
<body>
  <h2>INCOME STATEMENTS </h2>

<div class="table-wrapper"  >
    <table class="f2-table">
      <thead>
        <th colspan="2" >Profits</th>
      </thead>
        <tbody>
  <tr>
    <td> REVENUE </td>
    <td> <?=$revenue; ?></td>
  </tr>
  <tr>
    <td> COST OF GOOD SOLD </td>
    <td> <?=$cogs; ?></td>
  </tr>
  <tr>
    <td> Gross Profit </td>
    <td> <?=$gross_profit; ?></td>
  </tr>
 </tbody>
</table>
</div>

<div class="table-wrapper"  >
    <table class="f2-table">
      <thead>
        <th colspan="2" >Operating Expense</th>
      </thead>
        <tbody>
  <tr>
    <td> Wage Expense </td>
    <td> <?=$wage_exp; ?></td>
  </tr>
  <tr>
    <td> Rent Expense </td>
    <td> <?=$rent_exp; ?></td>
  </tr>
  <tr>
    <td> Supplier Expense </td>
    <td> <?=$supplier_exp; ?></td>
  </tr>
  <tr>
    <td> <strong>Total Expense</strong> </td>
    <td> <?=$total_expense; ?></td>
  </tr>
 </tbody>
</table>

<h2>RESULTS </h2>

<h3><strong>Operating Income:<strong> <?=$operating_income; ?>$,    <strong>Income Taxable Expense:</strong> <?=$income_taxes; ?>$,    <strong>Net Income:<strong> <?=$net_income; ?>$</h3>

</div>
</body>
