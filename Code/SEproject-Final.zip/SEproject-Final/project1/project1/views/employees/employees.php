
	<?php
	$css = "\css\\table.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
?>

<body>
<h2>Registered Employees</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>Departament</th>
            <th>joining Date</th>
						<th>Base Salary</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php
		foreach ($employees as &$employee) { ?>
      <tr>
         <td><?=$employee['id']; ?></td>
          <td><?=$employee['name']; ?></td>
          <td><?=$employee['departament']; ?></td>
					<td><?=$employee['joining_date']; ?></td>
					<td><?=$employee['base_salary']; ?></td>
      <form method="GET" action="">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$employee['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	} ?>


  <tr>
    <form method="POST" action="">
      <td>  <strong> NEW EMPLOYEE</strong> </td>
      <td>  <input type="text" name="name" required> </td>
      <td>
				<select id="job" name="departament_id" required>
					<optgroup label="Departaments" required>
						<?php foreach ($departaments as $departament) {?>
							<option value="<?=$departament['id']; ?>" required><?=$departament['name']; ?></option>";
						<?php   } ?>
					</optgroup>
				</select>
      </td>
			<td>  <input type="date" id="joining_date" name="joining_date" required> </td>
			<td>  <input type="number" id="salary" name="base_salary" required> </td>
      <td colspan="2">  <button type="submit" name="add">ADD</button> </td>
    </form>
  </tr>
 </tbody>
</table>
</div>
</body>
