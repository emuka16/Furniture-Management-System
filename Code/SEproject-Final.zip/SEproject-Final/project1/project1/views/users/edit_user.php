<?php
$css = "\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
    	<body>
    		<form action="" method="POST">

    			<h1>Register</h1>

    			<fieldset>
    				<legend><span class="number">1</span>Account Information</legend>
    				<label for="username">Username:</label>
    				<input value="<?= $username; ?>" type="text" id="username"  name="username" required>

    				<label for="mail">Email:</label>
    				<input value="<?= $user_email; ?>" type="email" id="mail" name="email" required>

    				<label for="password">Password:</label>
    				<input  value="<?=$user_password; ?>" type="password" id="password" name="password" required>

    				<label for="rpt_password">Repeat Password:</label>
    				<input  value="<?=$user_password; ?>" type="password" id="rpt_password" name="rpt_password" required>
    			</fieldset>

    			<fieldset>
    				<legend><span class="number">2</span>Personal Information</legend>

    				<label for="name">Name:</label>
    				<input value="<?=$user_name; ?>" type="text" id="name" name="name" required>

    				<label for="phone_number">phone Number:</label>
    				<input value="<?=$user_phone; ?>" type="text" id="phone_number" name="phone_number">

    				<label for="address">Address:</label>
    				<input value="<?=$user_addres; ?>" type="text" id="address" name="address">

    				<label for="cv">CV:</label>
    				<textarea id="cv" name="user_cv"></textarea>

    			</fieldset>
    			<fieldset>
    			<label for="job">Job Role:</label>
    			<select id="job" name="user_job" required>
    				<optgroup label="JOBS">
    					<option <?php if($user_role == 5) echo"selected"; ?> value="5">Manager</option>
    					<option <?php if($user_role == 1) echo"selected"; ?> value="1">administrator</option>
    					<option <?php if($user_role == 2) echo"selected"; ?> value="2">CFO</option>
    					<option <?php if($user_role == 3) echo"selected"; ?> value="3">Human Resource Specialist</option>
    					<option <?php if($user_role == 4) echo"selected"; ?> value="4">Sales Agent</option>
    				</optgroup>
    			</select>
    		</fieldset>
    			<button type="submit" name="update">UPDATE</button>
    		</form>

    	</body>
    </html>
    <?php
