
<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>

<body>
<h2>Users of the System</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>username</th>
            <th>Firstname</th>
            <th>email</th>
            <th>role</th>
						<th>Edit</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($users as $user) {
		    echo "<tr>";
		    echo "<td>".$user['id']."</td>";
		    echo "<td>".$user['username']."</td>";
		    echo "<td>" .$user['name']."</td>";
		    echo "<td>".$user['email']."</td>";
		    echo "<td>".$user['type']."</td>";
		    echo "<td><a href='edit_user.php?source=edit_user&edit_user=".$user['id']."'>EDIT</a></td>";
		    echo "<td><a href='users.php?delete=".$user['id']."'>DELETE</a></td>";
		    echo "</tr>";

		}
		?>
        <tr rawspan="2">
            <form method="GET" action="register.php">
                <td colspan="7">
                  <button type="submit">ADD USER</button>
                </td>
            </form>
        </tr>
		    </tbody>
		        </table>


</div>
</body>
