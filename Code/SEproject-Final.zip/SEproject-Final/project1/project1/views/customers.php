<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
<body>
<body>
<h2>CUSTOMERS</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
          <thead>
          <tr>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>address</th>
            <th>phone_number</th>
						<th>Edit</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($customers as $customer) { ?>
      <tr>
      <form method="POST" action="">
        <td>
          <input type="text" name="id" readonly value="<?=$customer['id']; ?>" required>
        </td>
          <td>
              <input type="text" name="name" value="<?=$customer['name']; ?>" required>
          </td>

          <td>
              <input type="text" name="address" value="<?=$customer['address']; ?>" required>
          </td>

          <td>
              <input type="text" name="phone_number" value="<?=$customer['phone_number']; ?>" >
          </td>

          <td colspan="1">
            <button type="submit" name="edit">EDIT</button>
          </td>

      </form>
      <form method="GET" action="">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$customer['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	}
		?>


    <tr>
    <form method="POST" action="">
      <td>
          <strong> NEW CUSTOMER</strong>
      </td>
        <td>
            <input type="text" name="name" required>
        </td>

        <td>
            <input type="text" name="address" required>
        </td>
        <td>
            <input type="text" name="phone_number" >
        </td>

        <td colspan="2">
          <button type="submit" name="add">ADD</button>
        </td>

    </form>
</tr>
		    </tbody>
		        </table>


</div>
</body>
