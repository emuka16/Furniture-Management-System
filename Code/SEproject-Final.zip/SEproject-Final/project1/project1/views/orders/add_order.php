
	<?php
	$css = "\css\style.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>

	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Add Order</h1>
				<legend><span class="number">1</span>ORDER DETAILS</legend>

        <label for="from">From:</label>
				<input type="text" id="from" name="order_from" value="Company" required>

        <label for="to">To:</label>
        <select id="to" name="order_to" required>
					<optgroup label="Customers" required>
						<?php foreach ($customers as $customer) {?>
							<option value="<?=$customer['id']; ?>" required><?=$customer['name']; ?></option>";
						<?php   } ?>
					</optgroup>
				</select>

        <label for="notes"> Special Notes</label>
        <textarea  rows="4" cols="50" name="notes" id="notes" form="form"></textarea>

        <legend><span class="number">2</span>Products</legend>
				<br>

          <?php foreach ($products as $product) { ?>
						<div id="<?=$product['id']; ?>">
            <input type="checkbox" name=<?=$product['name'] ; ?> value=<?=$product['id']; ?>
						onchange="addQuantityField(<?=$product['id']; ?>, this);"/><?=$product['name'] ; ?><br>
					  </div>
					<?php } ?>

       <br>
        <legend><span class="number">3</span>Amount</legend>

        <label for="tax">Tax:</label>
        <input type="number" id="tax" name="tax" >

        <label for="shipping">Shipping:</label>
        <input type="number" id="shipping" name="shipping">


			<button type="submit" name="add">Add</button>
		</form>

	</body>
</html>
<script>

function addQuantityField(id, check){
	console.log(id);
if(check.checked == true){
var y = document.createElement("INPUT");
y.setAttribute("type", "number");
y.setAttribute("placeholder", "Quantity");
y.setAttribute("Name", "item_"+id);
y.required = true;
var divi = document.getElementById(id);
divi.appendChild(y);
document.getElementById("form").appendChild(r);
}
else{
var input = document.getElementById(id).getElementsByTagName('input')[1];
input.remove();

}
}

</script>
