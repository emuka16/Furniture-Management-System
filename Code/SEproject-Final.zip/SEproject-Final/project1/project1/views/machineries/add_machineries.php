
<?php
$css = "\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Add machineries</h1>
			<fieldset>
				<legend><span class="number">1</span>Machinerie Information</legend>

        <label for="name">Machinery Name:</label>
				<input type="text" id="username" name="name" required>

        <label for="price">Machinery Price:</label>
				<input type="number" id="mail" name="price" required >

        <label for="quantity">Machinery Quantity:</label>
        <input type="number" id="password" name="quantity" required>

        <legend><span class="number">2</span>PHOTO</legend>

        <label for="post_image">Post image</label>
            <input type="file" name="image" required>

			</fieldset>

			<button type="submit" name="add">Add</button>
		</form>

	</body>
</html>
