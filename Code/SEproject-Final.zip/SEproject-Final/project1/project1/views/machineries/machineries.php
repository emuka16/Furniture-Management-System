
	<?php
	$css = "\css\list.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
?>


<body>
<div class="container">
	<?php foreach ($machineries as $machinery) { ?>

<div class="col-xs-12 col-md-6">
	<!-- First product box start here-->
	<div class="prod-info-main prod-wrap clearfix">
		<div class="row">
				<div class="col-md-5 col-sm-12 col-xs-12" style="left: 0px;">
					<div class="product-image" width="228px" height="228px">
						<img width="228px" height="228px" src='../images/<?=$machinery['image']; ?>' alt="194x228" class="img-responsive">
					</div>
				</div>
				<div class="col-md-7 col-sm-12 col-xs-12">
				<div class="product-deatil">
						<h5 class="name">
								<?=$machinery['name']; ?>
						</h5>
						<p class="price-container">
							<span><?=$machinery['price']; ?>$</span>
						</p>
						<p class="price-container">
							<span> No:<?=$machinery['quanity']; ?></span>
						</p>
						<span class="tag1"></span>
				</div>
				<div class="product-info smart-form">
					<div class="row">
						<div class="col-md-12">
							<a href='edit_machinery.php?edit_machinery=<?=$machinery['id']; ?>' class="btn btn-info">UPDATE</a>
              <a href='machineries.php?delete="<?=$machinery['id']; ?>"' class="btn btn-danger">DELETE</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end product -->

</div>

<?php } ?>
<a id="kot" href='add_machineries.php' class="btn btn-info">ADD</a>
</div>
</body>
</html>
