<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
?>

<body>

<h2>Orders</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
          <thead>
            <tr>
                <th colspan="4">PURCHASE</th>
            </tr>
          <tr>
        <tr>
            <th>id</th>
            <th>From</th>
            <th>To</th>
					  <th>Amount</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($purchases as &$purchase) { ?>
      <tr>
        <td><a href="purchase.php?id=<?=$purchase['id']; ?>"><?= 'Purchase '.$purchase['id']; ?></a></td>
          <td><?=$purchase['nga']; ?></td>
          <td><?=$purchase['per']; ?></td>
          <td><?=$purchase['total']; ?></td>
	<?php	}
		?>
    <tr>
    <td colspan="4">
      <a href='add_purchase.php' >ADD</a>
    </td>
    </tr>
 </tbody>
</table>
</div>
</body>
