<?php
$css = "\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Add Order</h1>
				<legend><span class="number">1</span>ORDER DETAILS</legend>

        <label for="from">From:</label>
				<input type="text" id="from" name="From" required>

        <label for="to">To:</label>
				<input type="text" id="to" name="To" required >

        <label for="notes"> Special Notes</label>
        <textarea  rows="4" cols="50" name="notes" id="notes" form="form"></textarea>

        <legend><span class="number">2</span>Materials</legend>
				<br>

          <?php foreach ($materials as $material) { ?>
						<div id="<?='material_'.$material['id']; ?>">
            <input type="checkbox" name=<?=$material['name'] ; ?> value=<?=$material['id']; ?>
						onchange="addQuantityField(<?=$material['id']; ?>, this);"/><?=$material['name'] ; ?><br>
					  </div>
					<?php } ?>

       <br>

       <legend><span class="number">3</span>Machineries</legend>
      <br>

         <?php foreach ($machineries as $machinery) { ?>
          <div id="<?='machinery_'.$machinery['id']; ?>">
           <input type="checkbox" name=<?=$machinery['name'] ; ?> value=<?=$machinery['id']; ?>
          onchange="addQuantityMachineryField(<?=$machinery['id']; ?>, this);"/><?=$machinery['name'] ; ?><br>
          </div>
        <?php } ?>

      <br>
        <legend><span class="number">3</span>Amount</legend>

        <label for="tax">Tax:</label>
        <input type="number" id="tax" name="tax" >

        <label for="shipping">Shipping:</label>
        <input type="number" id="shipping" name="shipping">


			<button type="submit" name="add">Add</button>
		</form>

	</body>
</html>
<script>
function addQuantityField(id, check){
	console.log(id);
if(check.checked == true){
var y = document.createElement("INPUT");
y.setAttribute("type", "number");
y.setAttribute("placeholder", "Quantity");
y.setAttribute("Name", "material_"+id);
y.required = true;
var id_div = "material_"+id;
console.log(id_div);
var divi = document.getElementById(id_div);
divi.appendChild(y);
document.getElementById("form").appendChild(r);
}
else{
var input = document.getElementById("material_"+id).getElementsByTagName('input')[1];
input.remove();

}
}

function addQuantityMachineryField(id, check){
	console.log(id);
if(check.checked == true){
var y = document.createElement("INPUT");
y.setAttribute("type", "number");
y.setAttribute("placeholder", "Quantity");
y.setAttribute("Name", "machinery_"+id);
y.required = true;
var divi = document.getElementById("machinery_"+id);
divi.appendChild(y);
}
else{
var input = document.getElementById("machinery_"+id).getElementsByTagName('input')[1];
input.remove();

}
}


</script>
