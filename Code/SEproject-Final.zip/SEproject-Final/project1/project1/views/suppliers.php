
<?php
$css = "\css\\table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>

<body>
<body>
<h2>Suppliers</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>address</th>
						<th>Edit</th>
					  <th>Delete</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($suppliers as $supplier) { ?>
      <tr>
      <form method="POST" action="">
        <td>
          <input type="text" name="id" readonly value="<?=$supplier['id']; ?>" required>
        </td>
          <td>
              <input type="text" name="name" value="<?=$supplier['name']; ?>" required>
          </td>

          <td>
              <input type="text" name="address" value="<?=$supplier['address']; ?>" required>
          </td>

          <td colspan="1">
            <button type="submit" name="edit">EDIT</button>
          </td>

      </form>
      <form method="GET" action="suppliers.php">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$supplier['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	}
		?>


    <tr>
    <form method="POST" action="">
      <td>
          <strong> NEW SUPPLIER</strong>
      </td>
        <td>
            <input type="text" name="name" required>
        </td>

        <td>
            <input type="text" name="address" required>
        </td>

        <td colspan="2">
          <button type="submit" name="add">ADD</button>
        </td>

    </form>
</tr>
		    </tbody>
		        </table>


</div>
</body>
