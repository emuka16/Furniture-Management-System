<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

		$query ="SELECT * FROM suppliers";
		$select_suppliers = mysqli_query($connection, $query);
    $suppliers = mysqli_fetch_all($select_suppliers,MYSQLI_ASSOC);
	    require 'views\suppliers.php';



    if(isset($_GET['delete']))   {

    $the_supplier_id = $_GET['delete'];

    $query ="DELETE FROM suppliers WHERE id = {$the_supplier_id}";
    $delete_query = mysqli_query($connection,$query);
    header("Location: suppliers.php");
    }



    if(isset($_POST['add']))   {
      $name = $_POST['name'];
      $address = $_POST['address'];
        $query ="INSERT INTO suppliers(name, address)
        VALUES('{$name}', '{$address}');";
        $query_result = mysqli_query($connection,$query);
        confirm($query_result);

        header("Location: suppliers.php");
    }



   if(isset($_POST['edit'])){
     $id = $_POST['id'];
     $name = $_POST['name'];
     $address = $_POST['address'];

     $query ="UPDATE suppliers SET
     name = '{$name}',
     address = '{$address}'
     WHERE id = '{$id}';";
     $query_result = mysqli_query($connection,$query);
     confirm($query_result);

     header("Location: suppliers.php");
 }

?>
