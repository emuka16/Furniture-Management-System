<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';
include 'helper\brand_helper.php';

$query ="SELECT * FROM products";
$select_products = mysqli_query($connection, $query);
$products = mysqli_fetch_all($select_products,MYSQLI_ASSOC);

$query ="SELECT * FROM brands";
$select_brands = mysqli_query($connection, $query);
$brands = mysqli_fetch_all($select_brands,MYSQLI_ASSOC);
$brand_map = get_brand_map($brands);

foreach ($products as &$product) {
  $id= $product['brand_id'];
  $product['brand'] = $brand_map[$id];
}



if(isset($_GET['delete']))   {

$the_product_id = $_GET['delete'];

$query ="DELETE FROM products WHERE id = {$the_product_id}";
$delete_query = mysqli_query($connection,$query);
header("Location: products.php");
}

require 'views\products\products.php';



 ?>
