<?php

ob_start();
session_start();
include 'includes\db.php';
include 'functions.php';
include 'helper\user_helper.php';

if($_SESSION['type']==1){

if(isset($_POST['register'])){

$valid_data = validateUser($_POST);
if($valid_data)
{
$username = $_POST['username'] ;
$email = $_POST['email'];
$password = $_POST['password'];
$rpt_password = $_POST['rpt_password'];
$name = $_POST['name'];
$user_job = $_POST['user_job'];
$phone_number = (isset($_POST['phone_number']) && !empty($_POST['phone_number'])) ? $_POST['phone_number'] : null;
$address =  (isset($_POST['address']) && !empty($_POST['address'])) ? $_POST['address'] : null;
$user_cv =  (isset($_POST['user_cv']) && !empty($_POST['user_cv'])) ? $_POST['user_cv'] : null;

if(!validateUserEmail($email)){
die("email is used!!!");
}
if(!validateUsername($username)){
  die("Username  is used!!!");
}
  //encode password
  $password = base64_encode($password);

  // create user query
  $create_user_query = "INSERT INTO users( username, name, password, email, phone_number, address, cv, joining_date, type )
  VALUES('{$username}', '{$name}','{$password}','{$email}', '{$phone_number}', '{$address}', '{$user_cv}', now(), '{$user_job}' )";

  $query_result = mysqli_query( $connection, $create_user_query);
  confirm($query_result);
  // REDIRECT
  header("Location: ../index.php");


}
}
require "views/users/register.php";
}
?>
