<?php
ob_start();
session_start();
include 'includes/db.php';
		$query ="SELECT * FROM users";
		$select_users = mysqli_query($connection, $query);
    $users = mysqli_fetch_all($select_users,MYSQLI_ASSOC);
   	mapUserType($users);
	require 'views\users\users.php';



if(isset($_GET['delete']))   {

    $the_user_id = $_GET['delete'];
		if($the_user_id == $_SESSION['id'])
		die('can not delete your self');
    $query ="DELETE FROM users WHERE id = {$the_user_id}";
    $delete_query = mysqli_query($connection,$query);
    header("Location: users.php");
    }

		 function mapUserType(&$users){
			foreach ($users as &$user) {
				if($user['type']==1)
				$user['type'] = "Administrator";
				if($user['type']==2)
				$user['type'] = "CFO";
				if($user['type']==3)
				$user['type'] = "Human Resource";
				if($user['type']==4)
				$user['type'] = "Sales";
				if($user['type']==5)
				$user['type'] = "Manager";
			}
		}

?>
