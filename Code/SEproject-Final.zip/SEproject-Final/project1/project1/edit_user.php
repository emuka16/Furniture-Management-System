<?php
ob_start();
session_start();
include 'includes/db.php';
include 'helper/user_helper.php';
include 'functions.php';

$the_user_id = null;
if(isset($_GET['edit_user'])){
    $the_user_id = $_GET['edit_user'];

 $query ="SELECT * FROM users WHERE id = $the_user_id";
 $select_users_query = mysqli_query($connection, $query);

 $row = mysqli_fetch_assoc($select_users_query);
     $user_id = $row['id'];
     $username = $row['username'];
     $user_password =base64_decode($row['password']);
     $user_name = $row['name'];
     $user_email = $row['email'];
     $user_role = $row['type'];
     $user_phone = $row['phone_number'];
     $user_addres = $row['address'];

}


if(isset($_POST['update'])){
  $valid_data = validateUser($_POST);
  if($valid_data)
  {
  $username = $_POST['username'] ;
  $email = $_POST['email'];
  $password = $_POST['password'];
  $rpt_password = $_POST['rpt_password'];
  $name = $_POST['name'];
  $user_job = $_POST['user_job'];
  $phone_number = (isset($_POST['phone_number']) && !empty($_POST['phone_number'])) ? $_POST['phone_number'] : null;
  $address =  (isset($_POST['address']) && !empty($_POST['address'])) ? $_POST['address'] : null;
  $user_cv =  (isset($_POST['user_cv']) && !empty($_POST['user_cv'])) ? $_POST['user_cv'] : null;

  if(!validateUserEmail($email, $the_user_id)){
  die("email is used!!!");
  }
  if(!validateUsername($username, $the_user_id )){
    die("Username  is used!!!");
  }
    //encode password
    $password = base64_encode($password);

   $query = "UPDATE users SET ";
   $query .= "username = '{$username}', ";
   $query .= "name = '{$name}', ";
   $query .= "password = '{$password}', ";
   $query .= "email = '{$email}', ";
   $query .= "phone_number = '{$phone_number}', ";
   $query .= "address = '{$address}', ";
   $query .= "password = '{$password}', ";
   $query .= " type = '{$user_job}' ";
   $query .= "  WHERE id = {$the_user_id} ;";

   $update_user = mysqli_query($connection,$query);
   confirm($update_user);
     header("Location: ../index.php");

}else{
die('jaa ke fut kot!');
}
}

include 'views\users\edit_user.php';
