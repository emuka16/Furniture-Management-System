<?php
ob_start();
session_start();
  $url = "income_statements.php";
include 'includes/sidebar.php';
include 'includes/db.php';
include 'functions.php';

/**
we get the month and the year of the time of the action was taken.
we check if the user clicked of one of the links in the side bar (months shown) and if the month was smaller that the actual
ex: april (4<6) than we check for record in the database for that month
if no statemant was made we throw a messageelse we show the use a view of the Statements
IF the user entered in the statement section by the header part and no month was indicated
we make a query in the statement table to see if the user has a statement forthe actual month.
if no statement was made than we show the add income statement view
For months that are yet to come we do not create Statements

**/
$month = (int) date('m');
$year = (int)date('Y');

if(isset($_GET['month'])&& $_GET['month'] < $month){
  $current_month = $_GET['month'];
  $query ="SELECT * FROM income_statements WHERE month= '{$current_month}' and year ='{$year}'; ";
  $select_income_statement = mysqli_query($connection, $query);
  $income_statement = mysqli_fetch_assoc($select_income_statement);
  if(sizeof($income_statement) == 0){
    $message = "No income registered this moth";
  require 'views\messagePage.php';  }
  else{
    // revenue

    $revenue_query = "SELECT SUM(invoice_orders.subtotal) AS revenue FROM invoice_orders;";
    $select_revenue =  mysqli_query($connection, $revenue_query);
    $revenue_tab = mysqli_fetch_assoc($select_revenue);
    $revenue = $revenue_tab['revenue'];
    //COGS
    $cogs_query = "SELECT SUM(order_products.quantity)*production_details.total_cost AS cogs
             FROM order_products, production_details
             WHERE order_products.product_id = production_details.product_id
             GROUP BY  order_products.product_id;";
    $select_cogs = mysqli_query($connection, $cogs_query);
    $cogs_tab = mysqli_fetch_assoc($select_cogs);
    $cogs = $cogs_tab['cogs'];
    // gross profit
    $gross_profit = $revenue - $cogs;
    // wage expense
    $wage_exp_query = "SELECT SUM(employees.base_salary) as wage FROM employees;";
    $wage_results = mysqli_query($connection, $wage_exp_query);
    $wage_exp_tab = mysqli_fetch_assoc($wage_results);
    $wage_exp = $wage_exp_tab['wage'];
    // Rent exp
    $rent_exp = $income_statement['rent'];

    // supplier exp
    $supplier_exp_query = "SELECT SUM(purchase.total) as supplier_exp FROM purchase;";
    $supplier_exp_results = mysqli_query($connection, $supplier_exp_query);
    $supplier_exp_tab = mysqli_fetch_assoc($supplier_exp_results);
    $supplier_exp = $supplier_exp_tab['supplier_exp'];
    // total operating exp
    $total_expense = $wage_exp + $rent_exp + $supplier_exp;
    $operating_income = $gross_profit - $total_expense;
    // income taxable expense that are stored in income_statements table
    $income_taxes = $income_statement['taxes'];
    // net income
    $net_income = $operating_income - $income_taxes;

    require 'views\income_statements\income_statement.php';

  }


}elseif(isset($_GET['month']) && $_GET['month'] > $month){
  $message = "No income registered this moth";
require 'views\messagePage.php';  }
else{
  $query ="SELECT * FROM income_statements WHERE month= '{$month}' and year ='{$year}'; ";
  $select_income_statement = mysqli_query($connection, $query);
  $income_statement = mysqli_fetch_assoc($select_income_statement);
  if(sizeof($income_statement) == 0){
    require 'views\income_statements\add_income_statement.php';
  }
  else{
    // revenue
    $revenue_query = "SELECT SUM(invoice_orders.subtotal) AS revenue FROM invoice_orders;";
    $select_revenue =  mysqli_query($connection, $revenue_query);
    $revenue_tab = mysqli_fetch_assoc($select_revenue);
    $revenue = $revenue_tab['revenue'];
    //COGS
    $cogs_query = "SELECT SUM(order_products.quantity)*production_details.total_cost AS cogs
             FROM order_products, production_details
             WHERE order_products.product_id = production_details.product_id
             GROUP BY  order_products.product_id;";
    $select_cogs = mysqli_query($connection, $cogs_query);
    $cogs_tab = mysqli_fetch_assoc($select_cogs);
    $cogs = $cogs_tab['cogs'];
    // gross profit
    $gross_profit = $revenue - $cogs;
    // wage expense
    $wage_exp_query = "SELECT SUM(employees.base_salary) as wage FROM employees;";
    $wage_results = mysqli_query($connection, $wage_exp_query);
    $wage_exp_tab = mysqli_fetch_assoc($wage_results);
    $wage_exp = $wage_exp_tab['wage'];
    // Rent exp
    $rent_exp = $income_statement['rent'];

    // supplier exp
    $supplier_exp_query = "SELECT SUM(purchase.total) as supplier_exp FROM purchase;";
    $supplier_exp_results = mysqli_query($connection, $supplier_exp_query);
    $supplier_exp_tab = mysqli_fetch_assoc($supplier_exp_results);
    $supplier_exp = $supplier_exp_tab['supplier_exp'];
    // total operating exp
    $total_expense = $wage_exp + $rent_exp + $supplier_exp;
    $operating_income = $gross_profit - $total_expense;
    // income taxable expense that are stored in income_statements table
    $income_taxes = $income_statement['taxes'];
    // net income
    $net_income = $operating_income - $income_taxes;

    require 'views\income_statements\income_statement.php';

  }

}


if(isset($_POST['add'])){
$tax = $_POST['tax'];
$rent = $_POST['rent'];

  $query =" INSERT INTO income_statements
  (rent, taxes, month, year) VALUES ('{$rent}', '{$tax}', '{$month}', '{$year}');";

  $query_result = mysqli_query($connection,$query);
  confirm($query_result);

header("Location: income_statements.php");
}





 ?>
