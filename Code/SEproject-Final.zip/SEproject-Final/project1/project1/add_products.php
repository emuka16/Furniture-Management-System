<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';
include 'helper\brand_helper.php';

$query ="SELECT * FROM brands";
$select_brands = mysqli_query($connection, $query);
$brands = mysqli_fetch_all($select_brands,MYSQLI_ASSOC);

if(isset($_POST['add'])){
  $name = $_POST['name'];
  $brand_id = $_POST['brand_id'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $description = (isset($_POST['description'])&& !empty($_POST['description']))? $_POST['description']: null;
  $availability = $_POST['availability'];
  $parameters = (isset($_POST['parameters'])&& !empty($_POST['parameters']))? $_POST['parameters']: null;
  $image = $_FILES['image']['name'];
  $image_temp = $_FILES['image']['tmp_name'];
  if(!move_uploaded_file($image_temp, "images/$image"))

  $create_user_query = "INSERT INTO products( name, brand_id, image, price, quantity, description, availability, parameters)
  VALUES('{$name}', '{$brand_id}','{$image}','{$price}', '{$quantity}', '{$description}', '{$availability}', '{$parameters}' )";

  $query_result = mysqli_query( $connection, $create_user_query);
  confirm($query_result);
  // REDIRECT
  header("Location: ../products.php");

}
require 'views\products\add_products.php';
