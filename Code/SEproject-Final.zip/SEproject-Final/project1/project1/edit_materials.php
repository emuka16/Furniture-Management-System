<?php
session_start();
include 'includes/db.php';
include 'functions.php';

$the_material_id = null;
if(isset($_GET['edit_material']) && !empty($_GET['edit_material'])){
    $the_material_id = $_GET['edit_material'];

 $query ="SELECT * FROM materials WHERE id = $the_material_id;";
 $select_material_query = mysqli_query($connection, $query);

 $material = mysqli_fetch_assoc($select_material_query);
 confirm($material);

}


if(isset($_POST['edit'])){

  $name = $_POST['name'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  // var_dump($_FILES);
  $image = (isset($_FILES['image']['name'])&& !empty($_FILES['image']['name']))? $_FILES['image']['name']: null;
  $image_temp = (isset($_FILES['image']['tmp_name'])&& !empty($_FILES['image']['tmp_name']))? $_FILES['image']['tmp_name']: null;

  if(!empty($image) && (!empty($image_temp))){
  if(!move_uploaded_file($image_temp, "images\\$image")){
    die('fotoooo');
  }
   }
   $query = "UPDATE materials SET ";
   $query .= "name = '{$name}', ";
   $query .= "price = '{$price}', ";
   $query .= "quantity = '{$quantity}' ";
   $query .=($image)? "  ,image = '{$image}' " : " ";
   $query .= "  WHERE id = {$the_material_id} ;";

   $update_material = mysqli_query($connection,$query);
   confirm($update_material);
   header("Location: ../materials.php");

}
 require 'views\materials\edit_material.php';

    ?>
