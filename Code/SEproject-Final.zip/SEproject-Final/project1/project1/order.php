<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

if(isset($_GET['id']) && !empty($_GET['id'])){
  $id = $_GET['id'];

$order_query = "SELECT * FROM company_orders WHERE id='{$id}';";
$select_order = mysqli_query($connection, $order_query);
$order = mysqli_fetch_assoc($select_order);
$customer_id = $order['order_to'];
// die(var_dump($order));

$order_item_query = "SELECT * FROM order_products WHERE order_id='{$id}';";
$select_order_items = mysqli_query($connection, $order_item_query);
$order_items = mysqli_fetch_all($select_order_items,MYSQLI_ASSOC);

$query ="SELECT * FROM customers where id='{$customer_id}'";
$select_customers = mysqli_query($connection, $query);
$customer = mysqli_fetch_assoc($select_customers);

require 'views\orders\order.php';
}

if (isset($_GET['delete'])) {

  $the_order = $_GET['delete'];

  $query = "DELETE FROM company_orders WHERE id = {$the_order}";
  $delete_query = mysqli_query($connection, $query);
  confirm($delete_query);

   $query = "UPDATE invoice_orders SET status = 1 WHERE order_id = '{$the_order}';";
   $update_query = mysqli_query($connection, $query);

  header("Location: orders.php");
}
