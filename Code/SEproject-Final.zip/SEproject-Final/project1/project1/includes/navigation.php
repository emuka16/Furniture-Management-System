
<?php
/*
this file is for links that are shown in the navigation (top of the web page)
for every link we control ifthe session is open and what type of user he is
*/
 include 'includes/header.php'; ?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
<?php if(isset($_SESSION) && ($_SESSION['type']==1)){ ?>
          <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php">Dashboard</a>
          </div>
  <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 3|| $_SESSION['type'] == 1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="employees.php">Employees</a>
            </div>
<?php } ?>
<?php if(!empty($_SESSION) && ($_SESSION['type'] == 2|| $_SESSION['type'] == 1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="suppliers.php">Supplier</a>
            </div>
<?php } ?>

<?php if(isset($_SESSION) && ($_SESSION['type'] == 5|| $_SESSION['type'] == 1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="machineries.php">Machineries</a>
            </div>
<?php } ?>
            <?php if(isset($_SESSION) && ($_SESSION['type'] == 5|| $_SESSION['type'] == 1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="materials.php">Materials</a>
            </div>
          <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 2|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="products.php">Products</a>
            </div>
          <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 4|| $_SESSION['type'] ==1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="customers.php">Customers</a>
            </div>
          <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 2|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="brand.php"> Brand </a>
            </div>
          <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 3|| $_SESSION['type'] == 1 )) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="departamets.php"> Departaments </a>
            </div>
          <?php } ?>

          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 4|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="invoice_orders.php"> Invoice </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 4|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="orders.php"> Orders </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 2|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="purchases.php"> Purchase </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 5|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="production_details.php">    Manifactured Product Process    </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 5|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="product_achivements.php">  Product Achivements  </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION) && ($_SESSION['type'] == 2|| $_SESSION['type'] == 1)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="income_statements.php">  Income Statements </a>
            </div>
          <?php } ?>
          <?php if(!empty($_SESSION)) { ?>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="includes/logout.php"> Logout </a>
            </div>
          <?php } ?>


            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
