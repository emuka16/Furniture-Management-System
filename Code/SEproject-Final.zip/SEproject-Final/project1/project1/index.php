<?php
session_start();
 include 'includes/db.php';
 if(!$_SESSION){
 include 'views/login.php';
}
else{ $message = "Welcome in Furniture Managemen System";
require 'views\messagePage.php';
}
