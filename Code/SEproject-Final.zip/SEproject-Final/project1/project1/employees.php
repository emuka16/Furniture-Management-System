
<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';
include 'helper\departaments_helper.php';


		$query ="SELECT * FROM employees";
		$select_employees = mysqli_query($connection, $query);
    $employees = mysqli_fetch_all($select_employees,MYSQLI_ASSOC);

    $query ="SELECT * FROM departaments";
    $select_departaments = mysqli_query($connection, $query);
    $departaments = mysqli_fetch_all($select_departaments,MYSQLI_ASSOC);
		$dep_map = get_departament_map($departaments);

    foreach ($employees as &$employee) {
      $id= $employee['departament_id'];
      $employee['departament'] = $dep_map[$id];
    }
    require 'views\employees\employees.php';




    if(isset($_GET['delete']))   {

    $the_employee_id = $_GET['delete'];

    $query ="DELETE FROM employees WHERE id = {$the_employee_id}";
    $delete_query = mysqli_query($connection,$query);
    header("Location: employees.php");
    }



    if(isset($_POST['add']))   {
      $name = $_POST['name'];
      $departament_id = $_POST['departament_id'];
      $joining_date = $_POST['joining_date'];
      $base_salary = $_POST['base_salary'];

      $query ="INSERT INTO employees(name, departament_id, joining_date, base_salary)
               VALUES('{$name}', '{$departament_id}','{$joining_date}', '{$base_salary}');";
      $query_result = mysqli_query($connection,$query);
				confirm($query_result);
			header("Location: employees.php");



    }



?>
