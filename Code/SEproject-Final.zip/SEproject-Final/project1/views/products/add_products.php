<?php
$css = ".\css\style.css";
include 'includes\header.php';include 'includes/navigation.php';
 ?>
	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Add Product</h1>
			<fieldset>
				<legend><span class="number">1</span>Product Information</legend>

        <label for="name">Product Name:</label>
				<input type="text" id="username" name="name" required>

        <select id="brand" name="brand_id" required>
          <optgroup label="BRAND" required>
            <?php foreach ($brands as $brand) {?>
              <option value="<?=$brand['id']; ?>" required><?=$brand['name']; ?></option>";
            <?php   } ?>
          </optgroup>
        </select>

        <label for="price">Product Price:</label>
				<input type="number" id="mail" name="price" required >

        <label for="quantity">Product Quantity:</label>
        <input type="number" id="password" name="quantity" required>

        <label for="availability">Is this product available:</label>
        <select id="job" name="availability" required>
            <option value="1">AVAILABLE</option>
            <option value="0">NON AVAILABLE</option>
        </select>

        <legend><span class="number">2</span>Product parameters</legend>

        <label for="description"> Description</label>
        <textarea rows="4" cols="50" name="description" id="description" form="form"></textarea>

        <label for="parameters"> Parameters </label>
        <textarea rows="4" cols="50" name="parameters" id="parameters" form="form"></textarea>

        <legend><span class="number">3</span>PHOTO</legend>

        <label for="post_image">Post image</label>
            <input type="file" name="image" required>

			</fieldset>

			<button type="submit" name="add">Add</button>
		</form>

	</body>
</html>
