<?php
$css = ".\css\list.css";
include 'includes\header.php';
include 'includes/navigation.php';
?>



<body>
<div class="container">
	<?php foreach ($products as &$product) { ?>

<div class="col-xs-12 col-md-6">
	<!-- First product box start here-->
	<div class="prod-info-main prod-wrap clearfix">
		<div class="row">
				<div class="col-md-5 col-sm-12 col-xs-12">
					<div class="product-image">
						<img src='./images/<?=$product['image']; ?>' alt="194x228" class="img-responsive">
						<span class="tag2 sale">
							SALE
						</span>
					</div>
				</div>
				<div class="col-md-7 col-sm-12 col-xs-12">
				<div class="product-deatil">
						<h5 class="name">
							<a href="#">
								<?=$product['name']; ?> <span> <?=$product['brand']; ?></span>
							</a>
						</h5>
						<p class="price-container">
							<span><?=$product['price']; ?>$</span>
						</p>
						<p class="price-container">
							<span> No:<?=$product['quantity']; ?></span>
						</p>
						<span class="tag1"></span>
				</div>
				<div class="description">
					<p><?=$product['description']; ?> </p>
				</div>
				<div class="product-info smart-form">
					<div class="row">
						<div class="col-md-12">
							<a href='edit_product.php?edit_product=<?=$product['id']; ?>' class="btn btn-info">UPDATE</a>
              <a href='products.php?delete="<?=$product['id']; ?>"' class="btn btn-danger">DELETE</a>
						</div>
						<div class="col-md-12">
							<div width ="40" class="description">
								<p><?=$product['parameters']; ?> </p>
							</div>
						</div>
						<div class="description">
							<p><strong><?php
							if($product['availability'] == 1) echo "Available";
							else echo'Not Available'; ?> </strong></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end product -->
</div>

<?php } ?>
<a href='add_products.php' class="btn btn-info">ADD</a>

</div>

</body>
</html>
