
	<?php
    $css = "./css/table.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>
 <style>
 body{
	 background-color: #76b852;
 }
 h1{
	 color: white;
	 text-align: center;
 }
 </style>

<body>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>

<h1><strong><?=$message ;?></strong> </h1>
<body>
