
<?php
$css = "./css/table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
<body>
  <h2>Product achivemets of the month</h2>
<div class="table-wrapper"  >
    <table class="f2-table">
        <thead>
        <tr>
            <th>id</th>
            <th>Product Name</th>
            <th>Achived </th>
            <th>Goal</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($achivements as $achivement) { ?>
      <tr>
        <td><?=$achivement['id']; ?></td>
          <td><?=$achivement['product_name']; ?></td>
          <td><?php if($achivement['achived_status']==1) echo"Achived"; else echo "Not Achived"; ?></td>
          <td><?=$achivement['achived_no']; ?></td>
        </tr>
	<?php	}
		?>
 </tbody>
</table>
</div>
</body>
