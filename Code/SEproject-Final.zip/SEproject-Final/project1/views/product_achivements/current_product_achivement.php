<?php
$css = "./css/table.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>

<body>
<body>
<h2>Product Achivements for this month</h2>

<div class="table-wrapper">
    <table class="f2-table">
        <thead>
          <tr>
              <th>id</th>
              <th>Product Name</th>
              <th>Achived </th>
              <th>Goal </th>
              <th>Update</th>
          </tr>
        </thead>
        <tbody>

	<?php

		foreach ($achivements as $achivement) { ?>
      <tr>
      <form method="POST" action="">
        <td>
          <input type="number" name="id" readonly value="<?=$achivement['id']; ?>" required>
        </td>
        <td>
            <input type="text" name="name" readonly value="<?=$achivement['product_name']; ?>" required>
        </td>
        <td>
    			<select id="Achivement" name="achived" required>
    						<option value="0" <?php if($achivement['achived_status']==0) echo'selected'; ?>>
                  <?='Not Achived' ;?></option>";
                  <option value="1" <?php if($achivement['achived_status']==1) echo'selected'; ?>>
                    <?='Achived'; ?></option>";
    			</select>
        </td>
        <td>
            <input type="number" name="goal"  value="<?=$achivement['achived_no']; ?>" required>
        </td>

          <td colspan="1">
                <button type="submit" name="edit" value="<?=$achivement['id']; ?>">Update</button>
         </td>
       </form>
     </tr>

	<?php	}
		?>
		    </tbody>
		        </table>


</div>
</body>
