<?php
$css = ".\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
?>


<body>

<form action="register.php" method="post"   enctype="multipart/form-data">

    <h1>Register</h1>

    <fieldset>
        <legend><span class="number">1</span>Account Information</legend>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="mail">Email:</label>
        <input type="email" id="mail" name="email" required >

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <label for="rpt_password">Repeat Password:</label>
        <input type="password" id="rpt_password" name="rpt_password" required>
    </fieldset>

    <fieldset>
        <legend><span class="number">2</span>Personal Information</legend>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="phone_number">phone Number:</label>
        <input type="text" id="phone_number" name="phone_number">

        <label for="address">Address:</label>
        <input type="text" id="address" name="address">

        <label for="cv">CV:</label>
        <input type="file" name="user_cv" required >

    </fieldset>
    <fieldset>
        <label for="job">Job Role:</label>
        <select id="job" name="user_job" required>
            <optgroup label="JOBS">
                <option value="5">Manager</option>
                <option value="1">administrator</option>
                <option value="2">CFO</option>
                <option value="3">Human Resource Specialist</option>
                <option value="4">Sales Agent</option>
            </optgroup>
        </select>
    </fieldset>
    <button type="submit" name="register">Add</button>
</form>

</body>
</html>