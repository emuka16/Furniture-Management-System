<?php
$css = ".\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
	<body>

		<form action="" method="post"  id ="form">

			<h1>Production Details</h1>
			<fieldset>
				<legend><span class="number">1</span>Product Information</legend>

        <label for="name">Product Name:</label>
        <select id="product" name="product_id" required>
            <?php foreach ($products as $product) {?>
              <option value="<?=$product['id']; ?>" required><?=$product['name']; ?></option>";
            <?php   } ?>
        </select>

        <legend><span class="number">2</span>Material Used</legend>
        <br>

          <?php foreach ($materials as $material) { ?>
            <div id="<?='material_'.$material['id']; ?>">
            <input type="checkbox" name=<?=$material['name'] ; ?> value=<?=$material['id']; ?>
                   onchange="addQuantityField(<?=$material['id']; ?>, this);"/><?=$material['name']." (".$material['price']."$)" ; ?><br>
            </div>
          <?php } ?>

       <br>

       <legend><span class="number">3</span>Other Costs</legend>

       <label for="machinery_costs">Machinery Costs:</label>
       <input type="number" id="machinery_cost" name="machinery_cost" required >

       <label for="work_hr">Working Hour Cost:</label>
       <input type="number" id="work_hr" name="work_hr" required>


			<button type="submit" name="add">Add</button>
		</form>

	</body>
  <script>
  function addQuantityField(id, check){
  	console.log(id);
  if(check.checked == true){
  var y = document.createElement("INPUT");
  y.setAttribute("type", "number");
  y.setAttribute("placeholder", "COST");
  y.setAttribute("Name", "material_"+id);
  y.required = true;
  var id_div = "material_"+id;
  console.log(id_div);
  var divi = document.getElementById(id_div);
  divi.appendChild(y);
  document.getElementById("form").appendChild(r);
  }
  else{
  var input = document.getElementById("material_"+id).getElementsByTagName('input')[1];
  input.remove();

  }
  }
  </script>
</html>
