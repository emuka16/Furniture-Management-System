
	<?php
	$css = ".\css\login.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>

<body>
<div class="login-page">
  <div class="form">
    <form class="register-form" >
      <input type="text" placeholder="name" />
      <input type="password" placeholder="password" />
      <input type="text" placeholder="email address" />
      <button>create</button>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
    <form class="login-form" action="includes\login.php" method="post">
      <input type="text" placeholder="username" name="username" required />
      <input type="password" placeholder="password" name="password" required />
      <button type="submit" name="login">login</button>
    </form>
  </div>
</div>
<body>
