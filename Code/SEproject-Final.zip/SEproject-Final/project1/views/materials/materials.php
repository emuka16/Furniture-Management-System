
	<?php
	$css = ".\css\list.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>

<body>
<div class="container">
	<?php foreach ($materials as &$material) { ?>

<div class="col-xs-12 col-md-6">
	<!-- First product box start here-->
	<div class="prod-info-main prod-wrap clearfix">
		<div class="row">
				<div class="col-md-5 col-sm-12 col-xs-12">
					<div class="product-image" width="228px" height="228px">
						<img src='./images/<?=$material['image'];?>'width="228px" height="228px"  alt="194x228" class="img-responsive">
						<span class="tag2 sale">
							Material
						</span>
					</div>
				</div>
				<div class="col-md-7 col-sm-12 col-xs-12">
				<div class="product-deatil">
						<h5 class="name">
								<?=$material['name']; ?>
						</h5>
						<p class="price-container">
							<span><?=$material['price']; ?>$</span>
						</p>
						<p class="price-container">
							<span> No:<?=$material['quantity']; ?></span>
						</p>
						<span class="tag1"></span>
				</div>
				<div class="product-info smart-form">
					<div class="row">
						<div class="col-md-12">
              <a href='edit_materials.php?edit_material=<?=$material['id']; ?>' class="btn btn-info">UPDATE</a>
              <a href='materials.php?delete="<?=$material['id']; ?>"' class="btn btn-danger">DELETE</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end product -->
</div>

<?php } ?>
<a href='add_material.php' class="btn btn-info">ADD</a>
</div>
</body>
</html>
