

<?php
$css = ".\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>

	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Edit Material</h1>
			<fieldset>
				<legend><span class="number">1</span>Material Information</legend>

        <label for="name">Material Name:</label>
				<input type="text" id="username" name="name"  value="<?=$material['name']; ?>" required>

        <label for="price">Material Price:</label>
				<input type="number" id="mail" name="price" value="<?=$material['price']; ?>" required >

        <label for="quantity">Material Quantity:</label>
        <input type="number" id="password" name="quantity"  value="<?=$material['quantity']; ?>" required>

        <legend><span class="number">2</span>PHOTO</legend>

        <label for="post_image">Post image</label>
            <input type="file" name="image" >

			</fieldset>

			<button type="submit" name="edit">Edit Material</button>
		</form>

	</body>
</html>
