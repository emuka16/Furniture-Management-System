<?php
$css = ".\css\ordePurchuase.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>


<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-12 brandSection">
                <div class="row">
                    <div class="col-md-12 col-sm-12 header">
                        <div class="col-md-3 col-sm-3 headerLeft">
                            <h1>Brand Logo</h1>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 content">
                        <h1>Purchase<strong>  <?=$purchase['id']; ?></strong></h1>
                        <p><?=$purchase['koha']; ?></p>
                    </div>
                    <div class="col-md-12 col-sm-12 panelPart">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 panelPart">
                              <div class="panel panel-default">
                                  <div class="panel-body">
                                      FROM
                                  </div>
                                  <div class="panel-footer">
                                      <div class="row">
                                          <div class="col-md-8 col-sm-6 col-xs-6">
                                            <p> <?=$purchase['nga']; ?></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-sm-6 panelPart">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        TO
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-md-8 col-sm-6 col-xs-6">
                                              <p> <?=$purchase['per']; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              </div>
                          </div>
                        </div>
                        <div class="col-md-12 col-sm-12 tableSection">
                            <h1>Materials</h1>
                            <table class="table text-center">
                              <thead>
                                <tr class="tableHead">
                                  <th style="width:30px;">Quantity</th>
                                  <th>Product Name</th>
                                  <th style="width:100px;">Unit Price</th>
                                  <th style="width:100px;text-align:center;">TOTAL</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($purchase_materials as $purchase_material) { ?>
                                  <tr>
                                    <td><?=$purchase_material['quantity']; ?></td>
                                    <td><?=$purchase_material['material_name']; ?></td>
                                    <td><?=$purchase_material['unit_price']; ?> $</td>
                                    <td><?=$purchase_material['total']; ?>$</td>
                                  </tr>
                                <?php } ?>
                              </tbody>
                          </table>
                        </div>
                        <div class="col-md-12 col-sm-12 tableSection">
                            <h1>Machineries</h1>
                            <table class="table text-center">
                              <thead>
                                <tr class="tableHead">
                                  <th style="width:30px;">Quantity</th>
                                  <th>Product Name</th>
                                  <th style="width:100px;">Unit Price</th>
                                  <th style="width:100px;text-align:center;">TOTAL</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($purchase_machineries as $purchase_machinerie) { ?>
                                  <tr>
                                    <td><?=$purchase_machinerie['quantity']; ?></td>
                                    <td><?=$purchase_machinerie['machinery_name']; ?></td>
                                    <td><?=$purchase_machinerie['unit_price']; ?> $</td>
                                    <td><?=$purchase_machinerie['total']; ?>$</td>
                                  </tr>
                                <?php } ?>
                              </tbody>
                          </table>
                        </div>
                        <div class="col-md-12 col-sm-12 lastSectionleft ">
                            <div class="row">
                                <div class="col-md-8 col-sm-6 Sectionleft">
                                    <p><i><?php if(!empty($purchase['special_notes'])) echo $purchase['special_notes']; ?></i></p>
                                    <span><i>Order of the company tha can not be modifies</i> </span>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body lastPanel">
                                          AMOUNT
                                      </div>
                                      <div class="panel-footer lastFooter">
                                          <div class="row">
                                              <div class="col-md-5 col-sm-6 col-xs-6 panelLastLeft">
                                                <p>SUBTOTAL</p>
                                                <p>TAX</p>
                                                <p>SHIPPING</p>
                                                <p>TOTAL</p>
                                              </div>
                                              <div class="col-md-7 col-sm-6 col-xs-6 panelLastRight">
                                                <p>$<?=$purchase['subtotal']; ?></p>
                                                <p>$<?php if(!empty($purchase['tax']))
                                                       echo $purchase['tax'];
                                                     else echo 0; ?></p>
                                                <p>$<?php if(!empty($purchase['shiping']))
                                                            echo $purchase['shiping'];
                                                          else echo 0; ?></p>
                                                <p><strong>$<?=$purchase['total']; ?></strong></p>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                </div>
                                <a href="purchase.php?delete=<?=$purchase['id'];?>">DELETE</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
				<
    </div>

</body>
</html>
