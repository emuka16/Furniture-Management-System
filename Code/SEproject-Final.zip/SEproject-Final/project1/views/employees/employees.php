
	<?php
    $css = "./css/table.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
?>

<body>
<h2>Registered Employees</h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>Departament</th>
            <th>joining Date</th>
						<th>Base Salary</th>
						<th>Update Employee</th>
					  <th>Delete Employee</th>
        </tr>
        </thead>
        <tbody>

	<?php
		foreach ($employees as &$employee) { ?>
      <tr>
				<form method="POST" action="">
					<td>
						<input readonly type="number" name="id" readonly value="<?=$employee['id']; ?>" required>
					</td>
					<td>
						<input  readonly type="text" name="name" value="<?=$employee['name']; ?>" required>
					</td>
					<td>
						<select id="job" name="departament_id" required>
							<optgroup label="Departaments" required>
								<?php foreach ($departaments as $departament) {?>
									<option value="<?=$departament['id']; ?>"
										<?php if($departament['id']==$employee['departament_id']) echo 'selected';?> required><?=$departament['name']; ?></option>";
								<?php   } ?>
							</optgroup>
					</td>
					<td>
						<input type="text" readonly name="joining_date" value="<?=$employee['joining_date']; ?>" required>
					</td>
					<td>
						<input type="number" name="base_satarye" value="<?=$employee['base_salary']; ?>" required>
					</td>
					<td>
						<button type="submit" name="update" value="<?=$employee['id']; ?>">Update</button>

					</td>
</form>


      <form method="GET" action="">
          <td colspan="1">
            <button type="submit" name="delete" value="<?=$employee['id']; ?>">DELETE</button>
          </td>
      </form>

	<?php	} ?>


  <tr>
    <form method="POST" action="">
      <td>  <strong> NEW EMPLOYEE</strong> </td>
      <td>  <input type="text" name="name" required> </td>
      <td>
				<select id="job" name="departament_id" required>
					<optgroup label="Departaments" required>
						<?php foreach ($departaments as $departament) {?>
							<option value="<?=$departament['id']; ?>" required><?=$departament['name']; ?></option>";
						<?php   } ?>
					</optgroup>
				</select>
      </td>
			<td>  <input type="date" id="joining_date" name="joining_date" required> </td>
			<td>  <input type="number" id="salary" name="base_salary" required> </td>
      <td colspan="2">  <button type="submit" name="add">ADD</button> </td>
    </form>
  </tr>
 </tbody>
</table>
</div>
</body>
