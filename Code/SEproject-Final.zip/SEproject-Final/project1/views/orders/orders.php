
<?php
$css = "./css/table.css";
include 'includes\header.php';
include 'includes/navigation.php';
?>

<body>
  <h2> Orders </h2>

<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>id</th>
            <th>From</th>
            <th>To</th>
					  <th>Address</th>
        </tr>
        </thead>
        <tbody>

	<?php

		foreach ($orders as &$order) { ?>
      <tr>
        <td><a href="order.php?id=<?=$order['id']; ?>"><?= 'Order '.$order['id']; ?></a></td>
          <td><?=$order['order_from']; ?></td>
          <td><?=$order['to']; ?></td>
          <td><?=$order['address']; ?></td>
	<?php	}
		?>
    <tr>
    <td colspan="4">
      <a href='add_order.php' >ADD</a>
    </td>
    </tr>
 </tbody>
</table>
</div>
</body>
