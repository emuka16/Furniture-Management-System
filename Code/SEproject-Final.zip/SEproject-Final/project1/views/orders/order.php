
	<?php
	$css = ".\css\ordePurchuase.css";
	include 'includes\header.php';
	include 'includes/navigation.php';
 ?>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-12 brandSection">
                <div class="row">
                    <div class="col-md-12 col-sm-12 header">
                        <div class="col-md-3 col-sm-3 headerLeft">
                            <h1>Order information </h1>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 content">
                        <h1>ORDER<strong>  <?=$order['id']; ?></strong></h1>
                        <p><?=$order['koha']; ?></p>
                    </div>
                    <div class="col-md-12 col-sm-12 panelPart">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 panelPart">
                              <div class="panel panel-default">
                                  <div class="panel-body">
                                      FROM
                                  </div>
                                  <div class="panel-footer">
                                      <div class="row">
                                          <div class="col-md-8 col-sm-6 col-xs-6">
                                            <p> <?=$order['order_from']; ?></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-sm-6 panelPart">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        TO
                                    </div>
                                    <div class="panel-footer">
                                        <div class="row">
                                            <div class="col-md-8 col-sm-6 col-xs-6">
                                              <p> <?=$customer['name']; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              </div>
                          </div>
                        </div>
                        <div class="col-md-12 col-sm-12 tableSection">
                            <h1>ITEMS</h1>
                            <table class="table text-center">
                              <thead>
                                <tr class="tableHead">
                                  <th>Product ID </th>
                                  <th>Product Name</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($order_items as $item) { ?>
                                  <tr>
                                    <td><?=$item['product_id']; ?></td>
                                    <td><?=$item['product_name']; ?></td>
                                  </tr>
                                <?php } ?>
                              </tbody>
                          </table>
                        </div>
                        <div class="col-md-12 col-sm-12 lastSectionleft ">
                            <div class="row">
                                <div class="col-md-8 col-sm-6 Sectionleft">
                                    <span><i>Order of the company tha can not be modified and if deleted
                                       the administrator will still keep track of it</i> </span>
                                </div>
                                <br>
                                <br>
                                <br>

                                <div class="col-md-4 col-sm-6">
                                </div>
                            </div>
                        </div>
                    </div>
                    <form method="GET" action="">

                          <button type="submit" name="delete" value="<?=$order['id']; ?>">DELETE</button>

                    </form>
                </div>
                </div>


        </div>


    </div>

</body>
</html>
