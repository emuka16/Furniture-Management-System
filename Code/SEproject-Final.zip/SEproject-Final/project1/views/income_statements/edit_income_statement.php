
<?php
$css = ".\css\style.css";
include 'includes\header.php';
include 'includes/navigation.php';
 ?>
	<body>

		<form action="" method="post" enctype="multipart/form-data" id ="form">

			<h1>Update Income Statement</h1>
			<fieldset>
				<legend><span class="number">1</span>Income Information</legend>

        <label for="name">Income Taxable Expense:</label>
				<input type="text" id="username" name="tax" value="<?=$income_statement['taxes']; ?>" required>

        <label for="price">Rent:</label>
				<input type="number" id="mail" name="rent" value="<?=$income_statement['rent']; ?>" required >

			<button type="submit" name="edit">UPDATE</button>
		</form>

	</body>
</html>
