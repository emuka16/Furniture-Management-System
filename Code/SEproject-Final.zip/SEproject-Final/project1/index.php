<?php
session_start();
 include 'includes/db.php';
 if(!$_SESSION){
 include 'views/login.php';
}
elseif($_SESSION['type']==1){
  require 'users.php';
}
else{ $message = "Welcome in Furniture Management System";
require 'views\messagePage.php';
}
