<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';
include 'helper/product_helper.php';

/** get all materials cause they are needed in the html form**/
$query ="SELECT * FROM materials";
$select_materials = mysqli_query($connection, $query);
$materials = mysqli_fetch_all($select_materials,MYSQLI_ASSOC);

$query ="SELECT * FROM products";
$select_products = mysqli_query($connection, $query);
$products = mysqli_fetch_all($select_products,MYSQLI_ASSOC);

/**
the logic is the same as in order
**/

if(isset($_POST['add'])){
  $product_id = $_POST['product_id'];
  $product_name = get_product_id($products, $product_id);

  // kontrollon per pjesen e producteve(items)
  $flag = false;
  $product_details = [];
  $subtotal = 0;
foreach ($materials as &$material) {
  $key = $material['name'];
  if(isset($_POST[$key]) && !empty($_POST[$key])){
    $flag = true;
    $product_detail['material_name'] = $key;
    $product_detail['id'] = $material['id'];
    $cost = 'material_'.$material['id'];
    $product_detail['cost'] = $_POST[$cost];
    $subtotal += $product_detail['cost'];
    $product_details[] =$product_detail;
  }
}
if(!$flag){
  $message = "There are no production detail";
require 'views\messagePage.php';
die();
}

// llogarit total
$work_hr = $_POST['work_hr'];
$machinery_cost = $_POST['machinery_cost'];
$total = $subtotal + $work_hr + $machinery_cost ;

$query = "INSERT INTO production_details(product_id, product_name, machinery_cost, work_hr_cost, production_time, total_cost)
VALUES('{$product_id}', '{$product_name}', '{$machinery_cost}', '{$work_hr}', now(), '{$total}');";

$query_result = mysqli_query( $connection, $query);
confirm($query_result);
$production_id =(int) mysqli_insert_id($connection);


foreach ($product_details as $product_detail) {
  $query = "INSERT INTO product_detail( production_id, material_id, material_name, material_cost)
  VALUES('{$production_id}','".$product_detail['id']."', '".
    $product_detail['material_name']."', '".$product_detail['cost']."');";
// die(var_dump($query));
  $query_result = mysqli_query( $connection, $query);

  confirm($query_result);
}

header("Location: production_details.php");

}


require 'views\production_details\add_production_details.php';

 ?>
