<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$query ="SELECT * FROM machineries";
$select_machineries = mysqli_query($connection, $query);
$machineries = mysqli_fetch_all($select_machineries,MYSQLI_ASSOC);


if(isset($_GET['delete']))   {

$the_machinerie_id = $_GET['delete'];

$query ="DELETE FROM machineries WHERE id = {$the_machinerie_id}";
$delete_query = mysqli_query($connection,$query);
header("Location: machineries.php");
}

require 'views\machineries\machineries.php';



 ?>
