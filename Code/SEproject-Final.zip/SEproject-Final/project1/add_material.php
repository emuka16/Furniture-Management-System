<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';


if(isset($_POST['add'])){
  $name = $_POST['name'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $image = $_FILES['image']['name'];
  $image_temp = $_FILES['image']['tmp_name'];
  if(!move_uploaded_file($image_temp, "images/$image")){
    $message = "Problem Uploading Photo";
  require 'views\messagePage.php';
  }

  $create_materials_query = "INSERT INTO materials( name, image, price, quantity)
  VALUES('{$name}','{$image}','{$price}', '{$quantity}');";

  $query_result = mysqli_query( $connection, $create_materials_query);
  confirm($query_result);
  // REDIRECT
  header("Location: materials.php");

}
require 'views\materials\add_material.php';
