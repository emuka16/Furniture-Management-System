<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';

$query ="SELECT * FROM materials";
$select_materials = mysqli_query($connection, $query);
$materials = mysqli_fetch_all($select_materials,MYSQLI_ASSOC);


if(isset($_GET['delete']))   {

$the_material_id = $_GET['delete'];

$query ="DELETE FROM materials WHERE id = {$the_material_id}";
$delete_query = mysqli_query($connection,$query);
confirm($delete_query);
header("Location: materials.php");
}

require 'views\materials\materials.php';



 ?>
