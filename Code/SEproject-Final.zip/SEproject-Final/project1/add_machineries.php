<?php
ob_start();
session_start();
include 'includes/db.php';
include 'functions.php';


if(isset($_POST['add'])){
  $name = $_POST['name'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $image = $_FILES['image']['name'];
  $image_temp = $_FILES['image']['tmp_name'];
  if(!move_uploaded_file($image_temp, "images/$image")){
    $message = "Problem Uploading Photo";
  require 'views\messagePage.php';
  }

  $create_machinery_query = "INSERT INTO machineries( name, image, price, quanity)
  VALUES('{$name}','{$image}','{$price}', '{$quantity}');";

  $query_result = mysqli_query( $connection, $create_machinery_query);
  confirm($query_result);
  // REDIRECT
  header("Location: machineries.php");

}
require 'views\machineries\add_machineries.php';
